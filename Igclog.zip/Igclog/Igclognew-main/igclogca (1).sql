-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Jun 25, 2023 at 06:38 AM
-- Server version: 10.10.2-MariaDB
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `igclogca`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_log_table`
--

DROP TABLE IF EXISTS `audit_log_table`;
CREATE TABLE IF NOT EXISTS `audit_log_table` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `infotable_id` int(11) NOT NULL,
  `server_name` varchar(255) DEFAULT NULL,
  `cdate` date NOT NULL,
  `ctime` varchar(25) DEFAULT NULL,
  `type` varchar(25) NOT NULL,
  `deamon_id` int(11) DEFAULT NULL,
  `cmd` text NOT NULL,
  `arch` varchar(255) DEFAULT NULL,
  `syscall` varchar(255) DEFAULT NULL,
  `success` varchar(255) DEFAULT NULL,
  `exit_code` varchar(255) DEFAULT NULL,
  `a0` varchar(255) DEFAULT NULL,
  `a1` varchar(255) DEFAULT NULL,
  `a2` varchar(255) DEFAULT NULL,
  `a3` varchar(255) DEFAULT NULL,
  `items` varchar(255) DEFAULT NULL,
  `ppid` varchar(255) DEFAULT NULL,
  `pid` varchar(255) DEFAULT NULL,
  `auid` varchar(255) DEFAULT NULL,
  `uid` varchar(255) DEFAULT NULL,
  `gid` varchar(255) DEFAULT NULL,
  `euid` varchar(255) DEFAULT NULL,
  `suid` int(11) DEFAULT 0,
  `fsuid` int(11) DEFAULT 0,
  `egid` int(11) DEFAULT 0,
  `sgid` int(11) DEFAULT 0,
  `fsgid` int(11) DEFAULT 0,
  `tty` varchar(255) DEFAULT NULL,
  `ses` varchar(255) DEFAULT '0',
  `comm` varchar(1000) DEFAULT NULL,
  `exe` varchar(1000) DEFAULT NULL,
  `msg` text DEFAULT NULL,
  `key_file` varchar(255) DEFAULT NULL,
  `item` varchar(15) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `inode` varchar(15) DEFAULT NULL,
  `dev` varchar(10) DEFAULT NULL,
  `mode` varchar(25) DEFAULT NULL,
  `ouid` int(11) NOT NULL DEFAULT 0,
  `ogid` int(11) NOT NULL DEFAULT 0,
  `rdev` varchar(25) DEFAULT NULL,
  `objtype` varchar(255) DEFAULT NULL,
  `cap_fp` varchar(50) DEFAULT NULL,
  `cap_fi` varchar(50) DEFAULT NULL,
  `cap_fe` int(11) DEFAULT 0,
  `cap_fver` int(11) NOT NULL DEFAULT 0,
  `grantors` varchar(255) DEFAULT NULL,
  `acct` varchar(255) DEFAULT NULL,
  `hostname` varchar(255) DEFAULT NULL,
  `addr` varchar(255) DEFAULT NULL,
  `terminal` varchar(255) DEFAULT NULL,
  `res` varchar(255) DEFAULT NULL,
  `op` varchar(255) DEFAULT NULL,
  `old_auid` varchar(255) DEFAULT NULL,
  `old_ses` varchar(255) DEFAULT NULL,
  `proctitle` varchar(255) DEFAULT NULL,
  `kind_field` varchar(255) DEFAULT NULL,
  `fp` varchar(255) DEFAULT NULL,
  `direction` varchar(255) DEFAULT NULL,
  `rport` varchar(255) DEFAULT NULL,
  `laddr` varchar(255) DEFAULT NULL,
  `lport` varchar(255) DEFAULT NULL,
  `cipher` varchar(255) DEFAULT NULL,
  `ksize` varchar(255) DEFAULT NULL,
  `mac` varchar(255) DEFAULT NULL,
  `pfs` varchar(255) DEFAULT NULL,
  `spid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `server_name` (`server_name`),
  KEY `cdate` (`cdate`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cron_files`
--

DROP TABLE IF EXISTS `cron_files`;
CREATE TABLE IF NOT EXISTS `cron_files` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `server_name` varchar(200) NOT NULL,
  `log_type` varchar(10) NOT NULL,
  `log_path` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `cdatetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cron_log_table`
--

DROP TABLE IF EXISTS `cron_log_table`;
CREATE TABLE IF NOT EXISTS `cron_log_table` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `infotable_id` int(11) NOT NULL,
  `cdate` date NOT NULL,
  `ctime` varchar(20) DEFAULT NULL,
  `jobname` varchar(1000) NOT NULL,
  `server_name` varchar(100) DEFAULT NULL,
  `job` varchar(60) DEFAULT NULL,
  `job_type` varchar(300) DEFAULT NULL,
  `jobid` int(11) DEFAULT NULL,
  `user` varchar(25) DEFAULT NULL,
  `command` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `cdate` (`cdate`),
  KEY `server_name` (`server_name`),
  KEY `job` (`job`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cron_table`
--

DROP TABLE IF EXISTS `cron_table`;
CREATE TABLE IF NOT EXISTS `cron_table` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `server_name` varchar(30) DEFAULT NULL,
  `log_type` varchar(20) NOT NULL,
  `log_path` varchar(512) NOT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `log_count` double NOT NULL DEFAULT 0,
  `msg` text DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `firewall_log`
--

DROP TABLE IF EXISTS `firewall_log`;
CREATE TABLE IF NOT EXISTS `firewall_log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `infotable_id` int(11) NOT NULL,
  `server_name` varchar(255) DEFAULT NULL,
  `cdate` date NOT NULL,
  `ctime` varchar(25) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `cmd_status` varchar(255) DEFAULT NULL,
  `cmd` varchar(255) DEFAULT NULL,
  `f1` varchar(255) DEFAULT NULL,
  `f2` varchar(255) DEFAULT NULL,
  `table_test` varchar(255) DEFAULT NULL,
  `filter` varchar(255) DEFAULT NULL,
  `chain_cmd` varchar(255) DEFAULT NULL,
  `chain_type` varchar(255) DEFAULT NULL,
  `src_ip` varchar(255) DEFAULT NULL,
  `dest_ip` varchar(255) DEFAULT NULL,
  `proto` varchar(255) DEFAULT NULL,
  `masq` varchar(255) DEFAULT NULL,
  `s_port_no` varchar(255) DEFAULT NULL,
  `d_port_no` varchar(255) DEFAULT NULL,
  `in_if` varchar(255) DEFAULT NULL,
  `in_if_name` varchar(255) DEFAULT NULL,
  `out_if` varchar(255) DEFAULT NULL,
  `out_if_name` varchar(255) DEFAULT NULL,
  `conntrack` varchar(255) DEFAULT NULL,
  `ctstate` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hardserver_log`
--

DROP TABLE IF EXISTS `hardserver_log`;
CREATE TABLE IF NOT EXISTS `hardserver_log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `infotable_id` int(11) NOT NULL,
  `server_name` varchar(255) DEFAULT NULL,
  `cdate` date NOT NULL,
  `ctime` varchar(25) NOT NULL,
  `deamon_id` varchar(50) DEFAULT NULL,
  `log_type` varchar(255) NOT NULL,
  `remarks` text DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `infotable`
--

DROP TABLE IF EXISTS `infotable`;
CREATE TABLE IF NOT EXISTS `infotable` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `file_path` varchar(1000) NOT NULL,
  `created_time` datetime NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages_log_table`
--

DROP TABLE IF EXISTS `messages_log_table`;
CREATE TABLE IF NOT EXISTS `messages_log_table` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `infotable_id` int(11) NOT NULL,
  `server_name` varchar(255) DEFAULT NULL,
  `cdate` date NOT NULL,
  `ctime` varchar(20) DEFAULT NULL,
  `type` varchar(50) NOT NULL,
  `subtype` varchar(50) DEFAULT NULL,
  `software` varchar(50) DEFAULT NULL,
  `swVersion` varchar(50) DEFAULT NULL,
  `x_pid` varchar(50) DEFAULT NULL,
  `x_info` varchar(100) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `msg` text NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `server_name` (`server_name`),
  KEY `cdate` (`cdate`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `secure_log`
--

DROP TABLE IF EXISTS `secure_log`;
CREATE TABLE IF NOT EXISTS `secure_log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `infotable_id` int(11) NOT NULL,
  `server_name` varchar(255) DEFAULT NULL,
  `cdate` date NOT NULL,
  `ctime` varchar(25) NOT NULL,
  `cmd` varchar(255) NOT NULL,
  `process` varchar(255) DEFAULT NULL,
  `process_cmd` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `logname` varchar(255) DEFAULT NULL,
  `uid` varchar(255) DEFAULT NULL,
  `euid` varchar(255) DEFAULT NULL,
  `tty` varchar(255) DEFAULT NULL,
  `ruser` varchar(255) DEFAULT NULL,
  `rhost` varchar(255) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `admin_user` varchar(255) DEFAULT NULL,
  `pwd` varchar(255) DEFAULT NULL,
  `command` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `timestamp_log`
--

DROP TABLE IF EXISTS `timestamp_log`;
CREATE TABLE IF NOT EXISTS `timestamp_log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `infotable_id` int(11) NOT NULL,
  `server_name` varchar(255) DEFAULT NULL,
  `cdate` date NOT NULL,
  `ctime` varchar(25) NOT NULL,
  `deamon_id` varchar(50) DEFAULT NULL,
  `command` varchar(255) DEFAULT NULL,
  `qry` varchar(255) DEFAULT NULL,
  `qry_no` varchar(255) DEFAULT NULL,
  `qry_type` varchar(255) DEFAULT NULL,
  `qry_details` text DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
