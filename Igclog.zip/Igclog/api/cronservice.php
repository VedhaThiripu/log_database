<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

// include config file 
include "CorsEnable.php";
// inlcude the error handle which handles all the files
require_once 'Core/CustomErrorHandler.php';
// load the autoloader class to laod the relevent classes 
require_once 'Core/Autoload.php';
// execute the cron 
\Cron\CronService::exec();

