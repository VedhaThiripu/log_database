<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of uploadSign
 *
 * @author SUBBA RAJU
 */
class uploadSign {
    private $_dest_path;
    //put your code here
    function __construct() {
        //
       // var_dump($_POST);
         $file_path_encrypted_mode = isset($_POST["filename"]) ? $_POST["filename"] : "";
         //
         $this->_dest_path = base64_decode($file_path_encrypted_mode);
         //
         $this->uploadFile();
    }
    // upload file in the directory specified 
    private function uploadFile(){
       // var_dump($_FILES);
       // echo  "dest = " . $this->_dest_path;
         if(isset($_FILES)){
              foreach($_FILES as $file){
                if(move_uploaded_file($file["tmp_name"], $this->_dest_path)){
                    echo "success";
                }else{
                    echo "failed";
                }        
                // return true
                return true;
            }
         }else{
			 echo "ivalid access";
		 }
    }
    
}

new uploadSign();
