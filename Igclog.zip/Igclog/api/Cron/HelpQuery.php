<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace Cron;

use Core\Helpers\Model as Model;
use Core\Helpers\Controller as Controller;
use Site\Helpers\TenderHelper as TenderHelper;
/**
 * Description of HelpQuery
 *
 * @author SUBBA RAJU
 */
class HelpQuery extends Controller{
    /**
     * 
     */
    static public function escalate_query(){
        $model = new Model();
        $data = $model->Select([
                "ID","io_time",
                "DATEDIFF(CURRENT_DATE(),io_time) as nodays",
                "status",
                "tender_id"
                ])
                ->From("help_query")
                ->Where("status = 5 OR status = 10")
                ->getDataFull([]);
        //var_dump($data);
        $db = new self();
        foreach($data as $obj){
            if(($obj->status ==5 || $obj->status==10) && $obj->nodays > 8){
               $db->escalate_to_rd($obj->ID, $obj->tender_id);
            }else if($obj->status ==5 && $obj->nodays > 3){
               $db->escalate_to_po($obj->ID, $obj->tender_id);
            }
        }
    }
    
   private function escalate_to_rd($id,$tender_id){
        $model = new Model("query");
        $model->Columns(["status"]);
        $model->update(["status"=>15],$id);
        //echo $id ." entered in to RD esclation tid=" . $tender_id ;
        // write a log 
        $tender_data = TenderHelper::getTenderData($tender_id);
        $this->write_log("indent",$tender_data->indentid, "System", "Query Escalated to RD ","","System");
    }
   private function escalate_to_po($id,$tender_id){
        $model = new Model("query");
        $model->Columns(["status"]);
        $model->update(["status"=>10],$id);
        echo $id ." entered in to po esclation tid=" . $tender_id ;
        // write a log 
        $tender_data = TenderHelper::getTenderData($tender_id);
        $this->write_log("indent",
                $tender_data->indentid, 
                "System", 
                "Query Escalated to Purchase Officer ",
                "",
                "system");
    }
}
