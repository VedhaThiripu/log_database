<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of digisign
 *
 * @author Raju
 */
//error_reporting(E_ALL);

include "CorsEnable.php";


session_start();
 
class digisign {
    //put your code here
    private $action=0;
    //
    private $ch;
    // serial number
    private $secret;
    //
    private $sign_no;

    private $json_url = "";
    
    private $sign_server = "";
    // dsc ra server
    private $dsc_ra_server ="";
    // http://dsca.igcar.anunet.in/igcarca/keyserver.php?type=emppfx&&icno=10851&&unitinfo=IGCAR
    private $curl_url;
    //
    private $unit;
    //
    private $icno;
	//
    private $sessid;
	// location
	private $ses_loc;
    
    function __construct() {
        // actions 
        $this->json_url = DIGI_SIGN_SERVER . "/iservernew/jsonstore";  
        // sign server 
        $this->sign_server = DIGI_SIGN_SERVER . "/iservernew/signserv"; 
        // ds ca server
        $this->dsc_ra_server = DSCA_SERVER ."/igcarca/keyserver.php?type=emppfxnew"; 
        
        
        // send flag
        $this->action = isset($_GET["action"]) ? trim($_GET["action"]) : "dummy";
        //
        $this->icno = isset($_GET["icno"]) ? trim($_GET["icno"]) : "dummy";
        //
        $this->unit = isset($_GET["unit"]) ? trim($_GET["unit"]) : "dummy";
        // get the secret flag
        $this->secret = isset($_GET["secret"]) ? trim($_GET["secret"]) : "1579617290126";
        // get the sign number
        $this->sign_no =  isset($_GET["signno"]) ? intval($_GET["signno"]) : 0; 
        //
        $this->sign_no = $this->sign_no - 1;
		//
	$this->sessid = $this->get_session_id();
	//
	$this->ses_loc = TMP.'session/'.$this->sessid.'cookie.txt';
        //
        if(!file_exists(TMP.'session/')){
            mkdir(TMP.'session/');
        }
        // dot he action
        echo $this->do_action();
    }
    
    private function get_session_id(){
       // var_dump($_SESSION);
        if(isset($_SESSION["userid"])){
            $userid = intval($_SESSION["userid"]);
            return session_id() . "_" .  $userid;
        }else{
            return "12345";
        }        
    }
    
    
    
    private function do_action(){
        switch($this->action){
            case 'getpfx' : return $this->get_pfx_file();
            case 'init'   : return $this->get_init_reponse();
            case 'gethash' : return $this->get_hash_response();
            case 'postsig' : return $this->post_signature();
            case 'final'   : return $this->final_reponse();
	    case 'storejson': return $this->store_json();
        }
    }
	
   private function store_json(){
     $ch = curl_init(); 
     curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/32.0.1700.107 Chrome/32.0.1700.107 Safari/537.36');
     $url = $this->json_url;
     $post_data = file_get_contents('php://input');
     //$post_data = json_decode($post_data);
     //var_dump($post_data);
     //$data = new stdclass();
     //$data->post = $post_data;
     
     curl_setopt($ch, CURLOPT_URL, $url);
     curl_setopt($ch, CURLOPT_POST, true);
     curl_setopt($ch, CURLOPT_POSTFIELDS, "postvar1=".$post_data);
     $answer = curl_exec($ch);
       if (curl_error($ch)) {
         echo curl_error($ch);
      } 
     // echo $answer;
    }
    
    // get pfx url
    private function get_pfx_file(){
      
      $pfx_url = $this->dsc_ra_server . "&&icno=".$this->icno."&&unitoff=".$this->unit."";
      //$pfx_url = $this->dsc_ra_server . "&&icno=".$this->icno."&&unitinfo=".$this->unit."";
     //  echo $pfx_url ."<br/>";
      $content =  file_get_contents($pfx_url);
      // returning the content
      return ($content);
    } 
    
    private function get_content($URL){
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_URL, $URL);
      $data = curl_exec($ch);
      curl_close($ch);
      return $data;
     }
    
    
   // build url
    private function build_url($send){  
         $this->curl_url = $this->sign_server."?send=".$send."&&secret=".$this->secret."&&signo=".$this->sign_no;        
         return $this->curl_url;
     }
    // getting the intial reponse
    private function get_init_reponse(){
        // initalize the curl operation with server
        $this->ch = $this->init_curl();
        // 10 indicates initial flag
        $curl_url = $this->build_url(10);
        //
        //echo $curl_url;
        
        $result = $this->exec_curl($this->ch,  $curl_url);
        //
        echo $result;
    }
    // get the hash of sign with sign number
    private function get_hash_response(){
        // new curl requet with the specified coockie
        $ch = $this->init_curl_new();
        // new hash url with sign number and secret
        $hash_url = $this->build_url(20);
        //echo $hash_url;
        // send request to server and get hash and submit
        $result = $this->exec_curl($ch, $hash_url);     
        // base64 encode
        return base64_encode($result);
    }
    // post the hash recived from url
    private function post_signature(){
        // intiate the connection with coockie
        $ch = $this->init_curl_new();
        //posted signature
        $posted_signature = file_get_contents('php://input');
        // decoded signature
        $decoded_data = base64_decode($posted_signature);
        //
        //echo "decoded data " . strlen($decoded_data);
        // post the signature
        $posted_result = $this->exec_curl_post($ch,$this->sign_server,$decoded_data);
        // result
        return $posted_result;
    }
    // get final response
    private function final_reponse(){
        // intiate the request
        $ch = $this->init_curl_new();
        // final url 
        $post_last_url = $this->build_url(30);
        // get the response
        $last_result = $this->exec_last_curl($ch, $post_last_url);
        //
        echo $last_result;
    }
    
    
    private function init_curl(){
        $ch = curl_init();    
        curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/32.0.1700.107 Chrome/32.0.1700.107 Safari/537.36');
       // curl_setopt($ch, CURLOPT_POST, false);
        //curl_setopt($ch, CURLOPT_POSTFIELDS, "username=XXXXX&password=XXXXX");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_COOKIESESSION, true); 
        curl_setopt($ch, CURLOPT_COOKIEJAR, $this->ses_loc);  //could be empty, but cause problems on some hosts
        curl_setopt($ch, CURLOPT_COOKIEFILE,$this->ses_loc);  //could be empty, but cause problems on some hosts
        return $ch;
    }    
    private function init_curl_new(){
        $ch = curl_init();    
        curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/32.0.1700.107 Chrome/32.0.1700.107 Safari/537.36');
       // curl_setopt($ch, CURLOPT_POST, false);
        //curl_setopt($ch, CURLOPT_POSTFIELDS, "username=XXXXX&password=XXXXX");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        //curl_setopt($ch, CURLOPT_COOKIESESSION, true);
        curl_setopt($ch, CURLOPT_COOKIEJAR, $this->ses_loc);  //could be empty, but cause problems on some hosts
        curl_setopt($ch, CURLOPT_COOKIEFILE, $this->ses_loc);  //could be empty, but cause problems on some hosts
        return $ch;
    }   
    // exec curl
    private function exec_curl($ch,$url){
            curl_setopt($ch, CURLOPT_URL, $url);
            $answer = curl_exec($ch);
            if (curl_error($ch)) {
                echo curl_error($ch);
            }
            return $answer;
    }
    
    private function exec_curl_post($ch,$url,$post_Data){
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_Data);
    $answer = curl_exec($ch);
    if (curl_error($ch)) {
        echo curl_error($ch);
    }
    return $answer;
    }

    private function exec_last_curl($ch,$url){
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, false);
        //curl_setopt($ch, CURLOPT_POSTFIELDS, "");
        $answer = curl_exec($ch);
        if (curl_error($ch)) {
            echo curl_error($ch);
        }
        return $answer;
    }
}

new digisign();
