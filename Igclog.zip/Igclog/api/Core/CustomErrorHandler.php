<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of CustomEroorHandler
 *
 * @author kms
 */
class CustomErrorHandler Extends ErrorException{
    //put your code here
    private $_errno;
    private $_errstr;
    private $_error_file;
    private $_error_line;
    
    private static $_instance = null;
    
    /**     
     * 
     * @param type $errno
     * @param type $errstr
     * @param type $error_file
     * @param type $error_line
     */
    static public function handleError($errno, $errstr=null,$error_file=null,$error_line=null){
          $obj = self::get_instance();
        // checking whetehr error is caught directly becasue of mysql fatol error 
        if($errno instanceof PDOException){
            $obj->_errno = E_USER_ERROR;
            $obj->_errstr = $errno->getMessage();
            $obj->_error_file = $errno->getFile();
            $obj->_error_line = $errno->getLine();
        }else{
         //echo $error_file ."   " . $error_line;
          debug_print_backtrace();
       // var_dump($errno);
        $obj->_errno = $errno;
        $obj->_errstr = $errstr;
        $obj->_error_file = $error_file;
        $obj->_error_line = $error_line;
        }
        $obj->process_error();
    }
    
   // static public function update_error
    
    // fatolr error for shutdown cases
    static public function handle_shutdown_function()
    {
         $last_error = error_get_last();
         if ($last_error && $last_error['type']==E_ERROR){            
             $obj = new self();
             $obj->_errno = $last_error["type"];
             $obj->_errstr =  $last_error["message"];
             $obj->_error_file = $last_error["file"];
             $obj->_error_line = $last_error["line"];
             $obj->generic_error_display();  
             die();
         }
         print_r($last_error);
         die();
    }
    /**
     * 
     */
    static public function handle_authentication_function()
    {
        $json = new stdClass();
        $json->status = "Unauthorized Access";
        $json->msg = " You Cannot Access This module";
        http_response_code(401);
        echo json_encode($json);
        exit();
       
    }
    
    static public function triger_error($msg){
        //debug_print_backtrace();
        $json = new stdClass();
        $json->status = "Error:";
        $json->msg = utf8_encode($msg);
        http_response_code(400);
        echo json_encode($json);
        exit();
    }
    
    static public function handle_RequestMethod_Error()
    {
        $method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : "";
        $json = new stdClass();
        $json->status = "Invalid Request Type";
        $json->msg = " Request type " .  $method ." for API is Invalid" ;
        http_response_code(401);
        echo json_encode($json);
        exit();
       
    }  
    
    public static function get_instance(){
           if(!isset(self::$_instance)){
              self::$_instance = new self();
           }
           return self::$_instance;
    }
    
    /**
     * 
     */
    private function process_error(){
       // debug_print_backtrace();
        if(!is_int($this->_errno)) $this->_errno = 11000;
                
         switch ($this->_errno) {
            case E_PARSE:
            case E_ERROR:
            case E_CORE_ERROR:
            case E_COMPILE_ERROR:
                $this->generic_error_display();
                break;
            case E_USER_ERROR:
                $this->handle_e_user_error();                
                break;
            case E_WARNING:
            case E_USER_WARNING:
                $this->handle_validation_error();
                break;
            case E_COMPILE_WARNING:
            case E_RECOVERABLE_ERROR:
                $this->generic_warining_display();
            case E_NOTICE:
                // this is to be logged  may be undefined errors are caught need not to exit
                $this->generic_warining_display();
                break;
            case E_USER_NOTICE:
                // user notics errors to show some error messages at fron end 
                $this->handle_e_user_notices();              
                break;
            case E_STRICT:
                 $this->generic_error_display();
                break;
            case E_DEPRECATED:
            case E_USER_DEPRECATED:
                $this->generic_error_display();
                break;
            default :
                $this->generic_error_display();
                break;
        }
       // exit();
    }
    /**
     * 
     */
    private function generic_error_display(){
        // check debug is on then dispaly other log the error 
        if (defined('FRAME_DEBUG') && FRAME_DEBUG===TRUE){
            // display the error 
            echo "<b>Error:</b> [$this->_errno] $this->_errstr - $this->_error_file:$this->_error_line <br/>";
            //
           // debug_print_backtrace();
            //
            die();
        }else{
            // log the error  now we will display later we will log it
            echo "<b>Error:</b> [$this->_errno] $this->_errstr - $this->_error_file:$this->_error_line <br/>";
        }
    }
    
    
    private function generic_warining_display(){
        // check debug is on then dispaly other log the error 
        if (defined('FRAME_DEBUG') && FRAME_DEBUG===TRUE){
            // display the error 
            echo "<b>Warning:</b> [$this->_errno] $this->_errstr - $this->_error_file:$this->_error_line <br/>";
            //
          //  die();
        }else{
            // log the error  now we will display later we will log it
            echo "<b>Warning:</b> [$this->_errno] $this->_errstr - $this->_error_file:$this->_error_line <br/>";
        }
    }
    
    /**
     * 
     */
    private function handle_e_user_notices(){
        $json = new stdClass();
        $json->status = "fail";
        $json->msg = $this->_errstr;
        http_response_code(404);
        echo json_encode($json);
        exit();
    }
    
     /**
     * 
     */
    private function handle_e_user_error(){
        $json = new stdClass();
        $json->status = "Error";
        $json->msg = $this->_errstr;
        http_response_code(400);
        echo json_encode($json);
        exit();
    }
    
     private function handle_validation_error(){
        $json = new stdClass();
        $json->status = "Validation Error";
        $json->msg = $this->_errstr==null ? "Invalid Error" : "";
        http_response_code(400);
        echo json_encode($json);
        exit();
    }
    
    
    
    
}
// we are handling errors here 
set_error_handler(array("CustomErrorHandler","handleError"));

set_exception_handler(array("CustomErrorHandler","handleError"));

register_shutdown_function(array("CustomErrorHandler","handle_shutdown_function"));