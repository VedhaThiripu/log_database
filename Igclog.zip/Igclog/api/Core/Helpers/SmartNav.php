<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Helpers;

//use Core\Helpers\Session Session

/**
 * Description of SmartNav
 *
 * @author kms
 */
class SmartNav {
    //put your code here
    private $_schema_file;
    //
    private $_schema;
    //
    private $_schema_single;
    //
    private  $_validation_check = true;   
    
    function __construct($navschema) {
       $this->_schema_file = $navschema;
       // loading schema
       $this->load_schema();
    }
    
    private function load_schema(){
        $dir = "Site/schema/navigations/";
        $file = $dir . $this->_schema_file .".json";
        //echo $file;
        if(!file_exists($file)) trigger_error("Schema File Does Not Exists : $this->_schema_file ",E_USER_ERROR);
        $json_str = file_get_contents($file);
        $this->_schema = json_decode($json_str,true);        
        
    }
    
    public function getNav() {
        $out = [];
        foreach($this->_schema as $single){
           $check = $this->permission_check($single);
           if($check === true){
              $out[]= $this->process_single_nav($single);
           } 
        }
        return $out;
    }

    private function role_check($roles){
        $emp = SmartGLobals::get("ROLES");
       // var_dump($emp);
        if(!is_array($emp)) {return false;}
        // check in groups indicated is available
       // var_dump($roles);
        $result = array_intersect($emp, $roles);
       // var_dump($result);
        // 
        return  empty($result) ? false : true; 
    }
    private function group_check($groups){
       
        $emp = SmartGLobals::get("GROUPNAMES");
       // echo "Employyees : <br/><br/>";
        //var_dump($emp);
         //echo "<br/>Employyees : <br/><br/>";
        if(!is_array($emp)) {return false;}
        // check in groups indicated is available 
        $result = array_intersect($emp, $groups);
        // 
      //   echo "Result : <br/><br/>";
       // var_dump($result);
        
        return  empty($result) ? false : true; 
    }

    private function single_condition_check($sperm){
        $names = isset($sperm["names"]) ?  $sperm["names"] : null;
        $type= isset($sperm["type"]) ?  $sperm["type"] : null;
        $check = null;
       // var_dump($sperm);
        //echo "<br/><br/>";
        switch($type){
            case "ROLES" : $check = $this->role_check($names);
                          break;
            case "GROUPS" : $check = $this->group_check($names);
                         break;
            default: break;
        }
        $join = isset($sperm["join"]) ?  $sperm["join"] : null;
        if($this->_validation_check!=NULL && $join!==null){
            $this->_validation_check =  $join==="AND" ? $this->_validation_check && $check : $this->_validation_check || $check;
        }else{
            $this->_validation_check =  $check;
        }
    }

    private function permission_check($single){
        $perm = isset($single["perm"]) ? $single["perm"] : [];
        $this->_validation_check = true;
        foreach($perm as $sperm){
            $this->single_condition_check($sperm);
            // echo "check = " . $col_name . " === " . $this->_validation_check . " <br/><br/>";            
           if($this->_validation_check===false){
               return $this->_validation_check;
           }
        }
        return $this->_validation_check;
    }
    
    private function process_single_nav($single){        
       $obj = new \stdClass();
       $obj->title = isset($single["title"]) ?  $single["title"] : "#";
       $obj->link =  isset($single["link"]) ?  $single["link"] : "#";
       $submenu = isset($single["submenu"]) ? $single["submenu"] : false;
       if($submenu!==false){
           $obj->submenu = $this->getSubMenu($submenu);
       }
       return $obj;
    }
    // get single submenu
    private function getSubMenu($submenu) {
        $out = [];
        foreach($submenu as $single){
           $out[] = $this->process_single_nav($single);  
        }
        return $out;
    }
    
    
    
    
    
    
}
