<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Helpers;

/**
 * Description of Validator
 *
 * @author kms
 */
class Validator {
    //put your code here
    private $_temp_data = [];
    private $_errors = [];
    private $_col_name = "";
    private $single_rule = [];
    
    //
    private $_validation_value = false;
    private $_validation_msg = false;
    
    private $_value="";
    
    /**
     * 
     * @param type $data
     */
    function __construct($data) {
        // get temp data
        $this->_temp_data = $data;
        // get errors 
        $this->_errors = [];
    }
    /**
     * 
     * @param type $table
     * @param type $unique
     */
    public function check_unique($table,$unique){
        // preparation of sql to check unique ness 
        $where = [];
        $data = [];
        foreach($unique as $column){
            $value = $this->get_value_from_data($column);
        }
    }
    
    /**
     * 
     * @param type $col_name
     * @param type $valid
     */
    public function validate_single_field($col_name,$valid){
        $this->_col_name = $col_name;
        $this->_value = $this->get_value_from_data($this->_col_name);       
        foreach($valid as $type=>$this->single_rule){     
             list($this->_validation_value,$this->_validation_msg) = $this->get_rule_value_and_msg($this->single_rule);
            // echo $this->_col_name . "  ". intval($this->_validation_value) ."   " . intval($this->_value) . "   <br/>";
            switch($type){
                case "required" : $this->do_validation_required(); break;
                case "isemail"  : $this->do_validation_isemail(); break;
                case "isint"  : $this->do_validation_isint(); break;
                case "isfloat"  : $this->do_validation_isfloat(); break;
                case "isdate"  : $this->do_validation_isdate(); break;
                case "min"  : $this->do_validation_min(); break;
                case "max"  : $this->do_validation_max(); break;
                case "lenbw"  : $this->do_validation_lenbw(); break;
                case "valbw"  : $this->do_validation_valbw(); break;
                case "wordbw" : $this->do_validation_wordbw(); break;
                case "minlen"  : $this->do_validation_minlen(); break;
                case "maxlen"  : $this->do_validation_maxlen(); break;
                case "minword"  : $this->do_validation_minword(); break;
                case "maxword"  : $this->do_validation_maxword(); break;
                case "alphanumeric"  : $this->do_validation_alphanumeric(); break;
                case "isIn"  : $this->do_validation_isIn(); break;
                case "notIn"  : $this->do_validation_notIn(); break;
                case "func"  : $this->do_validation_func(); break;
                default : break;
            }
        }
    }
    /**
     * 
     * @return type
     */
    public function getErrors(){
        return $this->_errors;
    }            
     /**
     * 
     * @param type $col_name
     * @param type $rules
     */
    private function do_validation_required(){
        list($value,$msg) = $this->get_rule_value_and_msg($this->single_rule);
        if($value==true){
            $act_value = $this->get_value_from_data($this->_col_name);
            if($act_value===null || strlen($act_value) < 1){
               $this->update_error($msg); 
            }
        }
    }
    /**
     * email validation
     */
    private function do_validation_isemail(){
      if(!filter_var($this->_value, FILTER_VALIDATE_EMAIL)){
           $this->update_error($this->_validation_msg); 
      }
    }
    /**
     * 
     */
    private function do_validation_isint(){
      if(!filter_var($this->_value, FILTER_VALIDATE_INT)){
           $this->update_error($this->_validation_msg); 
      }
    }
    /**
     * 
     */
    private function do_validation_isfloat(){
      if(!filter_var($this->_value, FILTER_VALIDATE_FLOAT)){
           $this->update_error($this->_validation_msg); 
      }
    }
    /**
     * 
     */
    private function do_validation_isdate(){
      if(!preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$this->_value)){
           $this->update_error($this->_validation_msg); 
      }
    }
    
    /**
     * 
     */
    private function do_validation_min(){
     // echo $this->_col_name . "  ". intval($this->_validation_value) ."   " . intval($this->_value) . "   <br/>";
      if(intval($this->_value) < intval($this->_validation_value)){     
           $this->update_error($this->_validation_msg); 
      }
    }
    /**
     * 
     */
    private function do_validation_max(){
     if(intval($this->_value) > intval($this->_validation_value)){  
           $this->update_error($this->_validation_msg); 
      }
    }
    /**
     * 
     */
     private function do_validation_minlen(){
      if(strlen(trim($this->_value)) < intval($this->_validation_value)){     
           $this->update_error($this->_validation_msg); 
      }
    }
    /**
     * 
     */
    private function do_validation_maxlen(){
      if(strlen(trim($this->_value)) > intval($this->_validation_value)){     
           $this->update_error($this->_validation_msg); 
      }
    }
    /**
     * 
     */
    private function do_validation_lenbw(){
       $length = strlen(trim($this->_value));
       $val = intval($this->_validation_value);
      if($length < $val || $length > $val){     
           $this->update_error($this->_validation_msg); 
      }
    }
    /**
     * 
     */
    private function do_validation_valbw(){
      $length = intval(trim($this->_value));
      $val = intval($this->_validation_value);
      if($length < $val || $length > $val){     
          $this->update_error($this->_validation_msg); 
      }
    }
    /**
     * 
     */
    private function do_validation_wordbw(){
      $length_arr = explode(" ",(trim($this->_value)));
      $length = count($length_arr);
      $val = intval($this->_validation_value);
      if($length < $val || $length > $val){     
          $this->update_error($this->_validation_msg); 
      }
    }
    /**
     * 
     */
    private function do_validation_minword(){
      $length_arr = explode(" ",(trim($this->_value)));
      $length = count($length_arr);
      if($length< intval($this->_validation_value)){     
           $this->update_error($this->_validation_msg); 
      }
    }
    /**
     * 
     */
    private function do_validation_maxword(){
      $length_arr = explode(" ",(trim($this->_value)));
      $length = count($length_arr);
      if($length >  intval($this->_validation_value)){     
           $this->update_error($this->_validation_msg); 
      }
    }
    /**
     * 
     */
    private function do_validation_alphanumeric(){
       if(preg_match('/[^a-z_\-0-9]/i', $this->_value))
        {
            $this->update_error($this->_validation_msg); 
        }   
    }
    /**
     * 
     */
    private function do_validation_isIn(){
        $haystack = is_array($this->_validation_value) ? $this->_validation_value : [$this->_validation_value];
        if(!in_array(trim($this->_value), $haystack)){
            $this->update_error($this->_validation_msg); 
        }
    }
    
    private function do_validation_notIn(){
        $haystack = is_array($this->_validation_value) ? $this->_validation_value : [$this->_validation_value];
        if(in_array(trim($this->_value), $haystack)){
            $this->update_error($this->_validation_msg); 
        }
    }
    
    private function do_validation_func(){
        // this is to be made ready we will take some time to impliment this
    }
    
    
    
    //filter_var($int, FILTER_VALIDATE_INT))
    
     /**
     * 
     * @param type $rules
     * @return type
     */
    private function get_rule_value_and_msg($rules){
        //var_dump($rules);
        $rule_value = isset($rules[0]) ? $rules[0] : null;
        $rule_msg = isset($rules[1]) ? $rules[1] : null;
        return [$rule_value,$rule_msg];
    }
   /**
    * 
    * @param type $column_name
    * @return type
    */
    private function get_value_from_data($column_name){
        if($this->_temp_data[$column_name]){
            $value = $this->_temp_data[$column_name];
            if(!is_array($value)){
                return trim($value);
            }else{
                return array_filter($value);
            }
        }else{
            return null;
        }
      //  return isset($this->_temp_data[$column_name]) && !is_array($this->_temp_data[$column_name]) ? trim($this->_temp_data[$column_name]) : null;
    }
    
     /**
    * 
    * @param type $col_name
    * @param type $msg
    */
    private function update_error($msg){
        $this->_errors[$this->_col_name] = $msg;
    }
    
    
    
}
