<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Helpers;

use Core\Helpers\SmartGLobals as Globals;

/**
 * Description of SmartInsert
 *
 * @author kms
 */
class SmartInsert {
    //put your code here
     private $_temp_data = [];
     private $_file_data =[];
     private $_schema=null;
     private $_columns;
     private $_sobj;
     
     private $_files=[];
     private $_filesnew=[];
     
     function __construct($data,$schema,$columns,$filedata=null) {
         $this->_temp_data = $data;
         $this->_schema = $schema;
         $this->_columns =$columns;
         $this->_file_data = $filedata;
     }
    /**
     * 
     * @return type
     */
    public function prepare_data(){
        $data =[];       
       // echo "data <br/>";
       //var_dump($this->_columns);
       //var_dump($this->_schema);
        foreach($this->_columns as $col_name){
             $this->_sobj = isset($this->_schema[$col_name]) ? $this->_schema[$col_name] : null;
             //var_dump($this->_sobj);
             if($this->_sobj!=NULL){
                // $col_type = isset($sobj["type"]) ? $sobj["type"] : "STRING";
                 $data[$col_name] = $this->get_data_with_type($col_name);
             }else{
                 $data[$col_name] = $this->get_value_from_data($col_name);
             }
        }
        //var_dump($data);
        //var_dump($this->_files);
        return [$data, $this->_files];
    }
    /**
     * 
     * @param type $col_name
     * @return type
     */
    private function get_data_with_type($col_name){
        $value = $this->get_value_from_data($col_name);        
        if($value===null){
            // check if default value is specified 
             $value = $this->get_default_value($col_name); 
        }        
        $type = isset($this->_sobj["coltype"]) ? $this->_sobj["coltype"] : "STRING";    
       // echo $type . "  " . $value . "  " . $col_name . "  <br/>";
        switch($type){
            case "STRING" : return trim($value); 
            case "INTEGER" :  return intval($value);
            case "FLOAT" : return floatval($value);
            case "TEXT" : return trim($value);
            case "DATE" :  return $this->get_data_date($value);
            case "DATETIME" :  return $this->get_data_date_time($value);
            case "TIME" :  return $this->get_time($value);
            case "FILE" : return $this->get_file_value($col_name);
            case "FILENEW" : return $this->get_file_new_value($col_name,$value);
            case "DEFAULT" : return $this->get_default_value($col_name);
            default : return $value;
        }
    }
    /**
     * 
     * @param type $col_name
     * @return string
     */
    private function get_file_value($col_name){
        //var_dump($this->_file_data);
        //echo $col_name;
        if(isset($this->_file_data[$col_name])){
            // file field is availble
            $store = isset($this->_sobj["store"]) ? $this->_sobj["store"] : null;
            
            if($store!==null){
                // store is avialble so process the data 
                $obj = new \stdClass();
                $obj->basedir = $store["baseDir"];
                $obj->fileName = $store["fileName"];
                $obj->file = $this->_file_data[$col_name];
                $obj->newfile = 0;
                $this->_files[$col_name] = $obj;
            }
            //var_dump($this->_files);
        }
        return "";
    }
    /**
     * 
     * @param type $col_name
     * @return string
     */
    private function get_file_new_value($col_name,$value){
        //var_dump($this->_file_data);
        //echo $col_name;
        if(!empty($value)){
            // file field is availble
            $store = isset($this->_sobj["store"]) ? $this->_sobj["store"] : null;            
            if($store!==null){               
                $obj = new \stdClass();
                $obj->basedir = $store["baseDir"];
                $actual_file = base64_decode($value);
                $file_ext = pathinfo($actual_file, PATHINFO_EXTENSION); 
                $obj->file = $actual_file;
                //$obj->filepath = 
                $obj->newfile = 1;
                $this->_files[$col_name] = $obj;
                $obj->fileName = $store["fileName"] . "." . $file_ext;
                // get the extenstion of the file 
                return $obj->fileName;
                
            }
            
        }
        return "";
    }
    
    
    private function get_value_global_session($type){
        // checking for global variables 
        if (strpos($type, 'GLOBAL_') !== false) { 
            $act_var = str_replace("GLOBAL_", "", $type);
            $act_val = Globals::get($act_var);
           // echo $act_var . " ===" . $act_val . " <br/><br/>";
            return $act_val;
        }        
        //$defau
        switch($type){         
            default : return $type;
        }
    }
    
    private function get_default_value($col_name){
        //echo "colname : " . $col_name;
        $default_type = isset($this->_sobj["defaultValue"]) ? $this->_sobj["defaultValue"] : "";
        return $this->get_value_global_session($default_type);
    }


    
    private function get_data_date($value){
        return \date("Y-m-d", strtotime($value));
    }
     private function get_data_date_time($value){
        return \date("Y-m-d H:i:s", strtotime($value));
    }
    
    private function get_time($value){
        return \date("H:i:s", strtotime($value));
    }
    
    private function get_value_from_data($column_name){
        if(isset($this->_temp_data[$column_name])){
            $value = $this->_temp_data[$column_name];
            if(!is_array($value)){
                return trim($value);
            }else{
                return implode(",",array_filter($value));
            }
        }else{
            return null;
        }
      //  return isset($this->_temp_data[$column_name]) && !is_array($this->_temp_data[$column_name]) ? trim($this->_temp_data[$column_name]) : null;
    }
     
    
}
