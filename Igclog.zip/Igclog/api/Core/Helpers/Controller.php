<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Helpers;
use Core\Helpers\SmartLogger as Logger;
use Core\Helpers\Zfile as Zfile;

/**
 * Description of Controller
 *
 * @author kms
 */
class Controller {
    //put your code here
    private $_data = [];
    public $_post = [];
    
    function __construct() {
       if(isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD']==='POST' && empty($_POST)) {
           $this->_post =  $_POST = json_decode(file_get_contents('php://input'),true); 
           $url = $this->getRequestedUrl();
          // Logger::info("post datas=".json_encode($this->_post),"controller : ". $url);
       }
    }
    
    private function getRequestedUrl() {
       $url = isset($_SERVER["REQUEST_URI"]) ? $_SERVER["REQUEST_URI"] : "";
       $escaped_url = htmlspecialchars( $url, ENT_QUOTES, 'UTF-8' );
       return $escaped_url;
    }
    
    /**
     *  function checks the request type and throws error if not matching
     * 
     */
    public function checkRequestType($method_required="GET"){
        $method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : "";
        if($method!==$method_required){
            ob_clean();
           \CustomErrorHandler:: handle_RequestMethod_Error();
        }
    }
    
    /**
     *  function checks the access control 
     * if this method is called it is indicating by default the api is
     *  accessible only for the logged in user only
     * 
     * 
     * @param type $groups  : array of groups names the api is accessible 
     * @param type $roles    : array of riles the names of the api is accessible
     */
    public function accessControl($groups=[],$roles=[]){
        $userid = Session::get("USERNAME");
        // check for login access 
        if($userid === null || strlen($userid) < 1){
             ob_clean();
            \CustomErrorHandler::handle_authentication_function();
        }
        //
        if(sizeof($roles) > 0 && $this->checkAccessRoles($roles)===false){
             ob_clean();
            \CustomErrorHandler::handle_authentication_function();
        }
        if(sizeof($groups) > 0 && $this->checkAccessGroups($groups)===false){
             ob_clean();
            \CustomErrorHandler::handle_authentication_function();
        }        
       
    }
    
    private function checkAccessRoles($roles){
       $ROLES_USER = Session::get("ROLES"); 
       foreach($roles as $single_role){
            if(in_array($single_role,  $ROLES_USER)){
                return true;               
            }
        }
       return false;
    }
     private function checkAccessGroups($groups){
       $GROUPS = Session::get("GROUPS"); 
       foreach( $groups as $single_group){
            if(in_array($single_group,  $GROUPS)){
                return true;               
            }
        }
       return false;
    }
    
    /**
     * 
     * @param type $data
     */    
    public function UpdateData($data){
        $this->_data = $data;        
    }
    //
    public function suceess_output($data){
        ob_clean();
        $this->_data = $data;
        http_response_code(200);      
        echo json_encode($this->_data);
        exit();
    }
    /**
     * 
     * @param type $data
     */
    public function succeess_output($data){
        ob_clean();
        $this->_data = $data;
        http_response_code(200);      
        echo json_encode($this->_data);
        exit();
    }
    
    
    
    
    public function registerCurd($schmaFile,$param,$datain,$file_data,$ret=false){
         $firstParam = isset($param["firstParam"]) ? $param["firstParam"] : "";
         $model = new Model($schmaFile);
          if($firstParam=="all"){            
             $data = $model->fetchAll();            
             $this->suceess_output($data);
        }elseif($firstParam=="delete"){    
             $id = isset($param["secondParam"]) ? $param["secondParam"] : 0;
            // $id = DATA::post_data("id","int");
             $model->deltewithid($id);
             $out = new \stdClass();
             $out->msg = "Deleted Successfully";
             $this->suceess_output($out);
        }elseif($firstParam=="insert"){             
             $model->insertwithdata($datain,$file_data);
             $out = new \stdClass();
             $out->msg = "successfully inserted";
             $this->suceess_output($out);  
        }elseif($firstParam=="get"){            
             $id = isset($param["secondParam"]) ? $param["secondParam"] : 0;
             $data = $model->fetchOne($id);
             if($ret===true ){
                 return $data;
             }else{
                 $this->suceess_output($data);  
             }  
        }elseif($firstParam=="update"){            
             $id = isset($param["secondParam"]) ? $param["secondParam"] : 0;
             $model->update($datain,$id);
             $out = new \stdClass();
             $out->msg = "successfully updated";
             $this->suceess_output($out);           
        }
    }
    
    /**
     * 
     * @param type $schema
     * @param type $postdata
     * @param type $filedata
     * @param type $columns
     */
    public function insert($schema,$postdata,$filedata,$columns=[]){
        $model = new Model($schema);
        if(sizeof($columns) > 0){
            $model->UpdateColumns($columns);
        }
        $data = $model->insertwithdata($postdata,$filedata);
        $this->suceess_output($data);  
    }
    /**
     * 
     * @param type $schema
     * @param type $postdata
     * @param type $filedata
     * @param type $id
     * @param type $columns
     */
     public function update($schema,$postdata,$filedata,$id,$columns=[]){
        $model = new Model($schema);
        if(sizeof($columns) > 0){
            $model->UpdateColumns($columns);
        }
        $where = [];
        $where["sql"] = "ID=:ID";
        $where["ID"]=$id;   
        $model->WhereSql($where);
        //var_dump($postdata);
        //var_dump($columns);         
        $data = $model->updatewithdata($postdata,$filedata);
        $this->suceess_output($data);  
    }
    
   /**
    * 
    * @param type $module
    * @param type $id
    * @param type $role
    * @param type $action
    * @param type $msg
    * @param type $emp
    */
    public function write_log($module,$id,$role,$action,$msg,$emp=null){
        $empname = Session::get("empname");
        $atts=[];
        $atts["mod"] = $module;
        $atts["id"] = $id;
        $atts["role"] = $role;
        $atts["action"] = $action;
        $atts["msg"] = $msg;
        $atts["emp"] = $emp===null ?  $empname : $emp;
        Zflog::log($atts);         
    }
   /**
    * 
    * @param type $html
    * @param type $location
    * @param type $settings
    */
    public function createpdf($html,$location,$settings=[]){
        try{
            Zpdf::genPdf($html, $location, $settings);
        }catch(Exception $ex){
           trigger_error($ex,E_USER_ERROR);
        }
    }
    
    /**
     * 
     * @param type $path
     * @return boolean
     */
    public function deleteFile($path){
        $full_path = DATA . $path;
        if(file_exists($full_path) && is_file($full_path)){
            unlink($full_path);
            return true;
        }
        return false;
    }
    /**
     * 
     * @param type $path
     */
    public function DownLoadFileNew($path){
       Zfile::DownloadFile($path);        
    }
    
    
    
}
