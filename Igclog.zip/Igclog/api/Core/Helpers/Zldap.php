<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Helpers;

/**
 * Description of Zldap
 *
 * @author kms
 */
class Zldap {

    //put your code here
    // ldap server ip address
    const LDAP_IP   = "10.30.1.71";
    // ldap port
    const LDAP_PORT = 389;
    // const manager 
    const MAN_DN    = "cn=ldapadm,dc=igcar,dc=com";
    // const Manager password 
    const MAN_PD    = "ldap@kms";
    // const for domain component with ,
    const DC        = ",dc=igcar,dc=com";
    //  const for domain component without the ,
    const DC1       = "dc=igcar,dc=com";

    //  link resource
    public $ds                = False;
    //
    private static $_instance = null;

    const AUTH_SERVER = "http://10.28.101.65/api/AuthData/";
    const EMP_GET_URL = "getEmpData";
    const EMP_LOGIN_URL = "checkLoginUserid";
    const GET_AUTHORS_URL = "getAuthors";
    const GET_UNITINFO_URL = "getUnitOff";
    const GET_DESIGNATIONS_URL = "getDesignations";

    /**
     * 
     * @param type $empid
     * @return type
     */
    public static function getEmpData($empid) {
        $obj = new self();
        return $obj->getUserData($empid);
    }

    public static function get_instance() {
        if (!isset(self::$_instance)) {
            self::$_instance = new Zldap();
        }
        return self::$_instance;
    }
    
    private function getUserCurlUrl($empid){
       $data_curl = self::exec_curl(self::AUTH_SERVER . self::EMP_GET_URL, ["empid" => $empid]);
        return $data_curl;
    }
    
    
    
    /**
     * 
     * @return type
     */
    public static function getUnitInfoCurl(){
       $data_curl = self::exec_curl(self::AUTH_SERVER . self::GET_UNITINFO_URL, []);
        return $data_curl;
    }
    // 
    public static function getDesigCurl(){
       $data_curl = self::exec_curl(self::AUTH_SERVER . self::GET_DESIGNATIONS_URL, []);
        return $data_curl;
    }
    
     public function get_curl_authors($term){
        $post_data = ["term"=>$term];
        $data_curl = self::exec_curl(self::AUTH_SERVER . self::GET_AUTHORS_URL, $post_data);
        return $data_curl;
    }
    

    /**
     * 
     * @param type $url
     * @param type $post_data
     * @return \Core\Helpers\stdclass
     */
    static public function exec_curl($url, $post_data) {
        $ch     = curl_init();
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/32.0.1700.107 Chrome/32.0.1700.107 Safari/537.36');
        //$url = $this->json_url;
        //$post_data = file_get_contents('php://input');
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        $result = curl_exec($ch);
        $obj    = new \stdclass();
        if (curl_errno($ch)) {
             curl_close($ch);
            $obj->error = true;
            $obj->msg   = "CURL ERROR" . curl_error($ch);
            return false;
        } else {
            $httpcode     = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $json_decoded = json_decode($result);
            if ($httpcode == 200) {
                 curl_close($ch);
                return $json_decoded;
            } else {
                $obj->error = true;
                $obj->msg   = $json_decoded->msg;
                curl_close($ch);
                return false;
            }
        }
        curl_close($ch);
       // return $obj;
    }

    /*
     *  constructor function fires when the object is created
     *  in this function it tries to connect to given ldap server
     *
     *  @param 		$ip        ipaddress of the ldap server
     *  the set option fucntion sets the version of ldap server using 
     */

    public function __construct($ip = NULL) {
        try {
            // getting the ip addresses
           // $ipaddr   = $ip == NULL ? self::LDAP_IP : $ip;
            // connecting to ldap server		 
           // $this->ds = @ldap_connect($ipaddr, self::LDAP_PORT) or die("not connected");
         //   ldap_set_option($this->ds, LDAP_OPT_PROTOCOL_VERSION, 3);
           // ldap_set_option($this->ds, LDAP_OPT_REFERRALS, 0);
            // echo "connected";
        } catch (\ErrorException $e) {
            //   var_dump($e);
        }
    }
    
    private function bindpass($username,$password){
        $post_data = [
            "userid"=>$username,
            "password"=>$password
        ];
        $data_curl = self::exec_curl(self::AUTH_SERVER . self::EMP_LOGIN_URL, $post_data);
        if($data_curl===false){
            return false;
        }else{
            return true;
        }
    }
    

    /*
     *  a bind function has been created and declared
     *  @param  $username  just the name of the user that needs to binded with ldap server
     *  @param  $password  password of the respective user
     *  @param  $flag      temporary variable
     *  
     */

    public function bind($username, $password, $flag = false) {
        // add the program to bypass the old ldap and use curl posting 
        return $this->bindpass($username, $password);
        
        if ($this->ds) {
            // get the username passed for the binding of individual users
            $username = $flag == true ? self::MAN_DN : "uid=" . $username . ",ou=People" . self::DC;
            // ldap binding is taking place
            try {
                $res = @ldap_bind($this->ds, $username, $password);
                if ($res) {
                    return true;
                } else {
                    return false;
                }
                // var_dump($err);
            } catch (\ErrorException $e) {
                // echo "Error Exception";
                // var_dump($e);
                return false;
            } catch (\Exception $ex) {
                //cho "Error Exception";
                // ar_dump($ex);
                return false;
            }
        } else {
            return false;
        }
    }

//bind function closed

    public function searchnew($query, $dn = "ou=People", $required = array(), $sortby = false) {

        if ($this->ds && $this->bind(self::MAN_DN, self::MAN_PD, true)) {
            // dn bulidng
            $dnn = $dn . "," . self::DC1;
            if (sizeof($required) > 0) {
                // if required parameters are specified
                $result = ldap_search($this->ds, $dnn, $query, $required);
            } else {
                //
                $result = ldap_search($this->ds, $dnn, $query);
            }
            //  sorting the result
            if ($sortby !== false) {
                ldap_sort($this->ds, $result, $sortby);
            }
            // getting the entities 
            $data = ldap_get_entries($this->ds, $result);
            // return the data
            return $data;
        } else {
            return "Not connected";
        }
    }

    public function getEmail($empid) {
        $data = $this->getUserData($empid);
        return isset($data->email) ? $data->email : "";
    }

   
    
    public function getUserData($icno) {
        // added new program 
       return $this->getuserCurlUrl($icno);

        // query preparation
        $query = "(uid=" . intval($icno) . ")";
        // search for the data
        $data  = $this->searchnew($query, "ou=People");

        // take the corresponsing values
        if (isset($data[0])) {
            $db                   = $data[0];
            $obj                  = new \stdClass();
            // $obj->icno = $icno;
            $obj->icno            = isset($db["employeenumber"]) ? $db["employeenumber"][0] : " ";
            $obj->displayname     = isset($db["displayname"]) ? $db["displayname"][0] : " ";
            $obj->name            = isset($db["displayname"]) ? $db["displayname"][0] : " ";
            $obj->fulldesig       = isset($db["fulldesig"]) ? $db["fulldesig"][0] : " ";
            $obj->desig           = isset($db["sn"]) ? $db["sn"][0] : " ";
            $obj->orgdisp         = isset($db["org"]) ? $db["org"][0] : " ";
            $obj->uoffice         = isset($db["unitoff"]) ? $db["unitoff"][0] : " ";
            $obj->telephonenumber = isset($db["telephonenumber"]) ? $db["telephonenumber"][0] : " ";
            $obj->empdesig        = isset($db["labeleduri"]) ? $db["labeleduri"][0] : " ";
            $obj->email           = isset($db["mail"]) ? $db["mail"][0] : " ";
            $obj->mail            = isset($db["mail"]) ? $db["mail"][0] : " ";
            $obj->shname          = isset($db["shname"]) ? $db["shname"][0] : " ";
            $obj->dhname          = isset($db["dhname"]) ? $db["dhname"][0] : " ";
            $obj->adname          = isset($db["adname"]) ? $db["adname"][0] : " ";
            $obj->gdname          = isset($db["gdname"]) ? $db["gdname"][0] : " ";
            $obj->head_details    = [];
            $obj->head_details[]  = $this->pack_head($obj->shname, "Section");
            $obj->head_details[]  = $this->pack_head($obj->dhname, "Division");
            $obj->head_details[]  = $this->pack_head($obj->adname, "SubGroup");
            $obj->head_details[]  = $this->pack_head($obj->gdname, "Group");
            return $obj;
        } else {
            return false;
        }
    }

    /**
     * 
     * @param type $emp
     * @param type $type
     * @return \Core\Helpers\stdClass
     */
    private function pack_head($emp, $type) {
        $obj           = new \stdClass();
        $obj->headname = $emp;
        $obj->itype    = $type;
        return $obj;
    }
    /**
     * 
     * @param type $term
     * @return type
     */
   
    /**
     * 
     * @param type $term
     * @return \Core\Helpers\stdClass
     */
    public function getAuthorsNew($term) {
        // do curl and get the details 
        return $this->get_curl_authors($term);
        // 
        $query = "(|(uid=*$term*)(displayname=*$term*))";
        $data  = $this->searchnew($query);
        $out   = array();
        // looping over the result 
        foreach ($data as $key => $db) {
            if ($key !== "count") {
                // dummy object
                $dbdata        = new \stdClass();
                //
                $uid           = $db["uid"][0];
                // employee name
                $dbdata->label = isset($db["displayname"]) ? $db["displayname"][0] . "(" . $uid . ")" : " ";
                // employee icnumber
                $dbdata->value = isset($db["uid"]) ? $db["displayname"][0] . "(" . $uid . ")" : " ";
                // placing the object in dummy array	
                $out[]         = $dbdata;
            }
        }
        return $out;
    }

}
