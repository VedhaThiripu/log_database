<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Database
 *
 * @author kms
 */
namespace Core\Helpers;
use Core\Helpers\SmartLogger as Logger;

use PDO;

class Database {
    //put your code here
    private $host      = DB_HOST;
    private $user      = DB_USER;
    private $pass      = DB_PASS;
    private $dbname    = DB_NAME;
    private $port = DB_PORT;
    
    private $dbh;
    private $error;
    private $stmt;
    
    private static $_instance = null;
 
    public function __construct(){  
        $this->connectdb();
    }
    
    private function connectdb(){
         // Set DSN
        $dsn = 'mysql:host='. $this->host . ';port='.$this->port.'; dbname=' . $this->dbname.";charset=utf8";
        // Set options
        $options = array(
            PDO::ATTR_PERSISTENT    => true,
            PDO::ATTR_ERRMODE       => PDO::ERRMODE_EXCEPTION
        );
        // Create a new PDO instanace
        try{
            $this->dbh = new PDO($dsn, $this->user, $this->pass, $options);
        }
        // Catch any errors
        catch(PDOException $e){
            $this->trigger_error_message($e);
        } 
    }
    //
    private function trigger_error_message($e){
         //var_dump($e);
         $msg = $e->getMessage();
         trigger_error("SQL Error: $msg",E_USER_ERROR);
         //exit()
    }

    public static function get_instance(){
        if(!isset(self::$_instance)){
           self::$_instance = new Database();
        }
        return self::$_instance;
    }
    
    /*
     * 
     * 
     */
    public function query($query){   
        try {
           // $ary = strip_tags($query);
           //echo $query . " <br/>";
           $this->stmt = $this->dbh->prepare($query);
            // ...yada yada yada, your PDO code goes here

          } catch (PDOException $e) {
            //   debug_print_backtrace();
            // This will echo the error message along with the file/line no on which the
            // exception was thrown. You could e.g. log the string to a file instead.
            echo $e->getMessage().' in '.$e->getFile().' on line '.$e->getLine();
            die();
          }
       
        
    }
    /*
     * 
     */
    public function bind($param, $value, $type = null){
            if (is_null($type)) {
                switch (true) {
                    case is_int($value):
                        $type = PDO::PARAM_INT;
                        break;
                    case is_bool($value):
                        $type = PDO::PARAM_BOOL;
                        break;
                    case is_null($value):
                        $type = PDO::PARAM_NULL;
                        break;
                    default:
                        $type = PDO::PARAM_STR;
                }
            }
            $this->stmt->bindValue($param, $value, $type);
    }
    /**
     * 
     * @return type
     */
    public function execute(){
        try{
            $return = $this->stmt->execute(); 
            return $return;
         } catch(PDOException $e){
            // var_dump($e);
             // debug_print_backtrace();
             
            $this->trigger_error_message($e);
         //   die();
        }

    }
        
        /*
         * 
         * 
         */
        public function resultset(){
            $this->execute();
            return $this->stmt->fetchAll(PDO::FETCH_OBJ);
        }
        
        /*
         * 
         */
        public function single(){
            $this->execute();
            return $this->stmt->fetch(PDO::FETCH_OBJ);
        }
        
        /*
         * 
         */
        public function rowCount(){
            return $this->stmt->rowCount();
        }
        
        /*
         * 
         */
       public function lastInsertId(){
            return $this->dbh->lastInsertId();
        }
        
      // insert the data in database  
      public function InsertData($table,$data) {
         $insertData = is_object($data) ? (array)$data : $data;
         $keys = array_keys( $insertData);
         // query preparation
         $sql = "INSERT INTO ".$table."";
         $sql .= "(". implode(",", $keys)  .") VALUES (:". implode(", :", $keys).")";
       //    Logger::info($sql,"SQL INSERT");
         //echo $sql;
         // preparation of the query 
         $this->prepare_sql_with_param($sql, $insertData);
         try{           
            $this->execute();
            $insertData["id"] = $this->lastInsertId();
            return $insertData;
         }catch (PDOException $e){
            $this->trigger_error_message($e);
         }
      }
      /**
       * 
       * @param type $table
       * @param type $data
       * @param type $where_sql
       * @param type $where_parameters
       */
       public function UpdateData($table,$data,$where) {
          $insertData = is_object($data) ? (array)$data : $data;
          
          $keys = array_keys( $insertData);
          
          $sql = "UPDATE ".$table." SET ";
          //echo "SQL1 = " . $sql;
          $temp = array();
          
          foreach($keys as $key) { $temp[] = $key." = :".$key;}
         // var_dump($temp);
          $sql .= implode(", ",$temp);         
          // get the where key from sql          
          $sql .= " WHERE " . $where["sql"];
          // 
          Logger::info($sql,"SQL UPDATE");
         // echo "sql = " . $sql;
          $where_data = array_slice($where, 1);
          // 
          foreach ($where_data as $k => $arg){
              $insertData[$k] = $arg;
          }
         // var_dump($insertData);
          $this->prepare_sql_with_param($sql, $insertData);
         try{           
           $this->execute();  
           // var_dump($ret);
            return $this->rowCount();
         }catch (PDOException $e){
            $this->trigger_error_message($e);
         }
          
       }
      
      // prepare and check exeute the sql
      private function prepare_sql_with_param($sql,$data){          
         $this->query($sql);         
         if(!is_array($data) || count($data) < 1) { return false;}
        // Logger::info(json_encode($data),"SQL INSERT DATA");
         foreach( $data as $key=>$value) {
            $this->bind(':'.$key,($value));
         }
      }
       /**
        * 
        * @param type $table
        * @param type $sql_str
        * @param type $data
        */        
      public function DeleteData($table,$sql_str,$data){
         $sql = "DELETE FROM ".$table." WHERE ".$sql_str."";
         $final_data = is_object($data) ? (array)$data : $data;
         $this->prepare_sql_with_param($sql, $final_data);
         try{           
           $this->execute();  
           return $this->rowCount();
           //   return $final_data;
          }catch (PDOException $e){
            $this->trigger_error_message($e);
         }
       }
       /**
        * 
        * @param type $sql_str
        * @param type $data
        * @param type $single
        */
       public function getData($sql_str,$data,$single=false){        
         $final_data = is_object($data) ? (array)$data : $data;
        // var_dump($final_data);
         //echo $sql_str;
         $this->prepare_sql_with_param($sql_str, $final_data);
         //echo $sql_str;
         try{ 
           // return data as per the query
           return $single==true ? $this->single() : $this->resultset();
           //   return $final_data;
          }catch (PDOException $e){
             // var_dump($e);
            $this->trigger_error_message($e);
         }
       }
       /**
        * 
        * @param type $table
        */
       public function fetchAllData($table){
           $sql = "SELECT *,ID as id FROM " . $table;
           $this->query($sql);
           try{           
            return  $this->resultset();        
            }catch (PDOException $e){
                $this->trigger_error_message($e);
            }
       }
      
      
     
      
      
 }  
