<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Autoload
 *
 * @author kms
 */
class Autoload {
    private $_classname ;
    // instance static variable 
    private static $_instance = null;
    //put your code here
       static public function load_class($classname){
           $obj = self::get_instance();
           $obj->_classname = $classname;
           $obj->load_class_with_name();
       } 
       // get instance
       public static function get_instance(){
           if(!isset(self::$_instance)){
              self::$_instance = new self();
           }
           return self::$_instance;
       }
       
       /**
        * 
        */
       private function load_class_with_name (){
             $extension = spl_autoload_extensions();             
             $className = str_replace('\\', DIRECTORY_SEPARATOR, $this->_classname);
             $filename = $className . $extension;         
             if(!file_exists($filename)) {
                if (strpos($filename, 'PHPExcel')!==false){                     
                }else{
                    trigger_error("PHP Class File Does Not Exists : $filename ",E_USER_ERROR);
                }
             }else{
                 require_once $filename;  
             }
               
       }
}

spl_autoload_extensions('.php');
spl_autoload_register(array("Autoload","load_class"));
