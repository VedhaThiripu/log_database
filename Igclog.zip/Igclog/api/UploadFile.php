<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of UploadFile
 *
 * @author SUBBA RAJU
 */

include "CorsEnable.php";


class UploadFile {
   // private $_dest_path;
    private $_emsg = "";
    private $_filepath;
    //put your code here
    function __construct() {   
       // uploading file 
      $this->uploadFile();
      // display the output back 
      $this->display_output();
    }
    
   private function display_output(){
       //$obj = new stdClass();
       if($this->_emsg!=""){
            $json = new stdClass();
            $json->status = "fail";
            $json->msg = $this->_emsg;
            http_response_code(404);
            echo json_encode($json);
            exit();
       }else{
            $json = new stdClass();          
            $json->file_path = $this->_filepath;
            http_response_code(200);
            echo json_encode($json);
            exit();
       }
   }


    private function generate_uuid() {
        return sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),
            mt_rand( 0, 0xffff ),
            mt_rand( 0, 0x0C2f ) | 0x4000,
            mt_rand( 0, 0x3fff ) | 0x8000,
            mt_rand( 0, 0x2Aff ), mt_rand( 0, 0xffD3 ), mt_rand( 0, 0xff4B )
        );
   }
    //
    private function getFilePath($ext){
        $file_name = $this->generate_uuid();
        return TMP . $file_name ."." . $ext;
    }
    
    private function getExt($filename){
        return $ext = pathinfo($filename, PATHINFO_EXTENSION);
    }
    
    private function move_single_file($file){       
        $name = isset($file["name"]) ? $file["name"] : "";
        $ext = $this->getExt($name);
        if(strlen($ext)<1){
            $this->_emsg = "Please Select valid File";
        }
        $file_path = $this->getFilePath($ext);
        //
        if(file_exists($file["tmp_name"])){
            if(move_uploaded_file($file["tmp_name"], $file_path)){
                 $this->_filepath = base64_encode($file_path); 
             }else{
                 $this->_emsg = "File Not Uploaded";
             }
         }else{
             $this->_emsg = "Invalid File Path";
         }
    }
    
    //put your code here
     private function uploadFile(){      
         if(isset($_FILES)){
             foreach($_FILES as $file){                  
                $this->move_single_file($file);
             }
         }else{
            $this->_emsg = "File not uploaded"; 
         }
    }
    
    
}

new UploadFile();
