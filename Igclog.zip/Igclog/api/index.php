<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
error_reporting(E_ALL);
ini_set("max_execution_time", "1000000");


include "CorsEnable.php";
// inlcude the error handle which handles all the files
require_once 'Core/CustomErrorHandler.php';
// load the autoloader class to laod the relevent classes 
require_once 'Core/Autoload.php';
// load the router class 
$router_paramters = \Core\Router::add_route();
// extract route parameters 
extract($router_paramters);
//
$mod_class_name = "\\Site\\Controller\\" . $Mod_Name;
// check for class exists 
if (!class_exists("\\Site\\Controller\\" . $Mod_Name)) {
    trigger_error("Module With Name:$Mod_Name Not Avilable",E_USER_NOTICE);
}
// 
$Frame_Class_Instance = new $mod_class_name();
// method exits
if(!method_exists($Frame_Class_Instance, $Func_Name)){
    trigger_error("API funciton: $Func_Name Not Availble Module With Name:$Mod_Name",E_USER_NOTICE);
}
// global pametres setting
\Core\Helpers\SmartGLobals::setGlobals();
//$logged_in = 1;
// check for authentication i.e whether the module is api is acceptable beore login ro any role based and through unauthroised error
if(method_exists("\\Site\\Authentication", "check_authentication")){
        Site\Authentication::check_authentication($Mod_Name);
}
//var_dump($_POST);
// all are availble execute 
call_user_func(array($Frame_Class_Instance, $Func_Name), $Param_var);
// over make die of script 
die();

