<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace Site\Controller;

use Core\Helpers\Model as Model;
use Core\Helpers\Controller as Controller;

//
use Site\Helpers\TableHelpers as Table;

/**
 * Description of CronFiles
 *
 * @author 91939
 */
class CronFiles Extends Controller {
    
    const SCHEMA = "log__cron_files";
    
     public function check_path($path) {              
        $sql = "log_path=:path";
        $model = new Model();
        $data = $model->From(Table::CRON_FILES)
                ->Where($sql)
                ->one()
                ->getDataFull(["path"=>$path]);
        return isset($data->ID) ? $data->ID : 0;
    }
    
    //put your code here
    
    public function get_all($param) {
        $this->checkRequestType("GET");
        $model = new Model();
        $data = $model->From(Table::CRON_FILES)
                ->Select(["*","IF(status=1,'Active','In-Active') as status_desc"])
                ->getDataFull([]);
        $this->succeess_output($data);
    }
    /**
     * 
     * @param type $param
     */
     public function get_one($param) {
        $this->checkRequestType("GET");
        $id = isset($param["firstParam"]) ? intval($param["firstParam"]) : 0;
        $sql = "ID=:id";
        $model = new Model();
        $data = $model->From(Table::CRON_FILES)
                ->Where($sql)
                ->one()
                ->getDataFull(["id"=>$id]);
        $this->succeess_output($data);
    }
    /**
     * 
     * @param type $param
     */
    public function insert_data($param) {
         $this->checkRequestType("POST");
        $path = \Core\Helpers\Data::post_data("log_path", "STRING");
        if($this->check_path($path)){
            \CustomErrorHandler::triger_error("Already log file is available");
        }
        $model = new Model(self::SCHEMA);
        $data = $model->insertwithdata($this->_post);
        $this->succeess_output($data);
    }
    
     public function update_data($param) {
        $this->checkRequestType("POST");
        $id = isset($param["firstParam"]) ? intval($param["firstParam"]) : 0;
        if($id < 1){
            \CustomErrorHandler::triger_error("Invalid ID");
        } 
        $model = new Model(self::SCHEMA);
        $columns = ["status"];
        $model->Columns($columns);
        $data = $model->update($this->_post, $id);
        $this->succeess_output($data);
    }
    /**
     * 
     * @param type $param
     */
      public function delete_one($param) {
        $this->checkRequestType("POST");
       $id = isset($param["firstParam"]) ? intval($param["firstParam"]) : 0;
        if($id < 1){
            \CustomErrorHandler::triger_error("Invalid ID");
        } 
        $model = new Model(self::SCHEMA);
        $model->deltewithid($id);
        $out = new \stdClass();
        $out->smsg = "Deleted siccessfully";
        $this->succeess_output($out);
    }
    
    
    
    
    
}
