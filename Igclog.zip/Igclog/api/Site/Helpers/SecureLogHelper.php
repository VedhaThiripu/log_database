<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

namespace Site\Helpers;

class SecureLogHelper {

    private $_line = "";
    //
    private $_exploded_arr = [];
    //
    private $_out = [];

    // get value
    private function get_value($index) {
        return isset($this->_exploded_arr[$index]) ? trim($this->_exploded_arr[$index]) : "";
    }

    private function get_str($str, $start, $end) {
        $startPos = strpos($str, $start);
        $endPos = strpos($str, $end);

        if ($startPos !== false && $endPos !== false) {
            $startPos += strlen($start);
            $extractedString = substr($str, $startPos, $endPos - $startPos);
            return $extractedString;
        } else {
            return "";
        }
    }

    /**
     * 
     * @return type
     */
    private function get_date_time() {
        $month = $this->get_value(0);
        $month_number = date("n", strtotime($month));
        $day = $this->get_value(2);
        $time = $this->get_value(3);
        $year = date("Y");
        return [$year . "-" . $month_number . "-" . $day, $time];
    }

    private function common_data() {
        list($this->_out["cdate"], $this->_out["ctime"]) = $this->get_date_time();
        $this->_out["cmd"] = str_replace("]", "", substr($this->get_value(5), 0, -1));
        $this->_out["server_name"] = $this->get_value(4);
    }

    private function extract_param($index) {
        foreach ($this->_exploded_arr as $text) {
            if (strpos(strtolower($text), $index . "=") !== false) {
                $this->_out[$index] = str_replace($index . '=', "", strtolower($text));
            }
        }
    }
    
    private function get_remarks() {
        $remarks = "";
        for($i=7;$i<count($this->_exploded_arr);$i++){
            $text = $this->_exploded_arr[$i];                  
            if (strpos(strtolower($text), "logname=") !== false) {
                break;
            }
            $remarks .= " " . $text; 
        }
        return $remarks;
    }

    private function get_gdm_parameters() {
        $exploded = explode("(", $this->get_value(6));
        $this->_out["process"] = isset($exploded[0]) ? $exploded[0] : "";
        $this->_out["process_cmd"] = isset($exploded[1]) ? $this->get_str($exploded[1], ":", ")") : "";
      //  $this->_out["remarks"] = $this->get_value(8);
        $this->extract_param("logname");
        $this->extract_param("uid");
        $this->extract_param("euid");
        $this->extract_param("tty");
        $this->extract_param("ruser");
        $this->extract_param("rhost");
        $this->extract_param("user");
        $this->_out["remarks"] = $this->get_remarks();
    }

    private function get_unix_parameters() {
        $this->_out["process"] = $this->get_value(6);
        $this->_out["process_cmd"] = $this->get_value(7);
        $msg_arr = array_slice($this->_exploded_arr, 6);
        $this->_out["remarks"] = implode(" ", $msg_arr);
    }

    private function get_sudo_parameters() {
        $this->_out["process"] = $this->get_value(6);
        $this->_out["process_cmd"] = $this->get_value(7);
        $this->extract_param("tty");
        $this->extract_param("pwd");
        $this->extract_param("user");
        $this->extract_param("command");
    }

    private function get_passwd_parameters() {
        $this->_out["process"] = $this->get_value(6);
        $this->_out["process_cmd"] = $this->get_value(7);
        $msg_arr = array_slice($this->_exploded_arr, 7);
        $this->_out["remarks"] = implode(" ", $msg_arr);
    }

    private function get_paratmers_with_type() {
        switch ($this->_out["cmd"]) {
            case "gdm-password":
                $this->get_gdm_parameters();
                break;
            case "unix_chkpwd":
                $this->get_unix_parameters();
                break;
            case "sudo": $this->get_sudo_parameters();
                break;
            case "passwd" : $this->get_passwd_parameters();
                break;
            default: break;
        }
    }

    /**
     * 
     * @param type $line
     */
    public function get_data($line) {
        $this->_line = $line;
        // explode
        $this->_exploded_arr = explode(" ", $line);
        //
        //var_dump($this->_exploded_arr);
        //
        $this->_out = [];
        //
        $this->common_data();
        //
        $this->get_paratmers_with_type();
        //var_dump($this->_out);
        // return 
        return $this->_out;
    }

    /**
     * 
     * @param type $line
     */
    static public function getData($line) {
        $obj = new self();
        return $obj->get_data($line);
    }

}

/*
   first one
 * 
  SYSCALL: Records a system call made by a process.
CRED_ACQ: Records the acquisition of a user credential.
CRED_DISP: Records the disposal of a user credential.
USER_START: Records the start of a user session.
USER_END: Records the end of a user session.
USER_LOGIN: Records a user login attempt.
USER_LOGOUT: Records a user logout event.
USER_AUTH: Records a user authentication event.
USER_ACCT: Records user account changes (e.g., password changes).
CONFIG_CHANGE: Records system configuration changes.
SYSTEM_RUNLEVEL: Records changes to the system runlevel (e.g., startup, shutdown).
SECCOMP: Records the use of the seccomp facility.
NETFILTER_CFG: Records changes to the netfilter configuration.
MAC_POLICY_LOAD: Records the loading of a MAC policy.
MAC_STATUS: Records the status of the MAC system.
ANOM_ABEND: Records an abnormal program termination.
ANOM_PROMISCUOUS: Records a change in network interface promiscuous mode.
ANOM_LOGIN_FAILURES: Records repeated failed login attempts.
 
 */

