<?php

namespace Site\Helpers;

use Core\Helpers\Model as Model;
// site helpers
use Site\Helpers\DnsLogHelper as DnsLogHelper;
use Site\Helpers\CronLogHelper as CronLogHelper;
use Site\Helpers\AuditLogHelper as AuditLogHelper;
use Site\Helpers\MsgLogHelper as MsgLogHelper;
use Site\Helpers\TimeStampLogHelper as TimeStampLogHelper;
use Site\Helpers\HardServerLogHelper as HardServerLogHelper;
// 
use Site\Helpers\TableHelpers as Table;

class LogAddHelper {

    CONST CRON_SCHEMA = "log__cron_log_table";
    CONST DNS_SCHEMA = "log__dns_log_table";
    CONST AUDIT_SCHEMA = "log__audit_log_table";
    CONST MESSAGE_SCHEMA = "log__messages_log_table";
    CONST TIMESTAMP_SCHEMA = "log__timestamp_log";
    CONST HARDSERVER_SCHEMA = "log__hardserver_log";
    CONST SECURE_SCHEMA = "log__secure_log";
    CONST FIREWALL_SCHEMA = "log__firewall_log";
    CONST RASERVER_SCHEMA = "log__raserver_log";
    CONST BOOTLOG_SCHEMA = "log__boot_log";
    CONST OCSPLOG_SCHEMA = "log__ocsp_log";

    /**
     * 
     * @param type $id
     * @return type
     */
    static public function getSingleCat($id) {
        $model = new Model();
        $data = $model->Select(["category"])
                ->From(Table::INFOTABLE)
                ->One()
                ->Where("ID=:id")
                ->getDataFull(["id" => $id]);
        return isset($data->category) ? $data->category : "##";
    }

    /**
     * 
     * @return string
     */
    static public function getcat() {
        if (isset($GLOBALS["log_types_config"])) {
            return $GLOBALS["log_types_config"];
        }
        $cats = [
            "AUDIT" => "Audit Log",
            "MSG" => "Messages",
            "CRON" => "Cron Log",
            "DNS" => "DNS Log",
            "TIMESTAMP" => "Timestamp Log"
        ];
        return $cats;
    }

    /**
     * 
     * @param type $line
     * @param type $type
     * @return type
     */
    static public function extract_line_insert($line, $type, $id) {
        switch ($type) {
            case "CRON" :
                $dt = self::extract_cron($line);
                self::insert_cron($dt, $id);
                break;
            case "MSG" :
                $dt = self::extract_message($line);
                self::insert_message($dt, $id);
                break;
            case "DNS" :
                $dt = self::extract_dns($line);
                self::insert_dns($dt, $id);
                break;
            case "AUDIT" :
                $dt = self::extract_audit($line);
                self::insert_audit($dt, $id);
                break;
            case "TIMESTAMP" :
                $dt = self::extract_timestamp($line);
                self::insert_timestamp($dt, $id);
                break;
            case "HARDSERVER" :
                $dt = HardServerLogHelper::getData($line);
                self::insert_generic(self::HARDSERVER_SCHEMA, $dt, $id);
                break;
            case "RASERVER" :
                $dt = RaServerLogHelper::getData($line);
                self::insert_generic(self::RASERVER_SCHEMA, $dt, $id);
                break;
            case "BOOT" :
                $dt = BootLogHelper::getData($line);
                self::insert_generic(self::BOOTLOG_SCHEMA, $dt, $id);
                break;
            case "SECURE" :
                $dt = SecureLogHelper::getData($line);
                self::insert_generic(self::SECURE_SCHEMA, $dt, $id);
                break;
            case "FIREWALL" :
                $dt = FirewallLogHelper::getData($line);
                self::insert_generic(self::FIREWALL_SCHEMA, $dt, $id);
                break;
            case "OCSP" :
                $dt = OcspLogHelper::getData($line);
                self::insert_generic(self::OCSPLOG_SCHEMA, $dt, $id);
                break;
            default: return [];
        }
    }

    /* 8
     * 
     */

    static public function extract_insert_log($log_file, $id, $type) {
        $log_handle = fopen($log_file, 'r');
        $i = 0;
        $line = "";
        $total_count = defined('TOTAL_COUNT') ? TOTAL_COUNT : 0;
        while (!feof($log_handle)) {
            $line = fgets($log_handle);
            self::extract_line_insert($line, $type, $id);
            $i++;
            // echo "total _count = " .  $total_count  . "  " . $i; 
            if ($total_count != 0 && $i > $total_count) {
                break;
            }
        }
        fclose($log_handle);
    }

    static public function check_cat($cat) {
        $cats = self::getcat();
        return isset($cats[$cat]) ? true : false;
    }

    /**
     * 
     */
    static public function read_first_line($log_file) {
        $log_handle = fopen($log_file, 'r');
        $i = 0;
        $line = "";
        while (!feof($log_handle)) {
            $line = fgets($log_handle);
            $i++;
            if ($i > 0) {
                break;
            }
        }

        fclose($log_handle);
        return $line;
    }

    /**
     * 
     * @param type $line
     * @return type
     */
    static public function extract_cron($line) {
        return CronLogHelper::getData($line);
    }

    static public function extract_dns($line) {
        return DnsLogHelper::getDnsDdata($line);
    }

    static public function extract_audit($line) {
        return AuditLogHelper::getData($line);
    }

    static public function extract_message($line) {
        return MsgLogHelper::getData($line);
    }

    static public function extract_timestamp($line) {
        return TimeStampLogHelper::getData($line);
    }

    /**
     *  insert functions 
     */

    /**
     * 
     * @param type $data
     * @param type $id
     */
    static public function insert_cron($data, $id) {
        if (is_array($data) && count($data) > 1) {
            $data_in = $data;
            $data_in["infotable_id"] = $id;
            // var_dump($data_in);
            $model = new Model(self::CRON_SCHEMA);
            $model->insertwithdata($data_in);
            // exit();
        }
    }

    /**
     * 
     * @param type $data
     * @param type $id
     */
    static public function insert_dns($data, $id) {
        if (is_array($data) && count($data) > 1) {
            $data_in = $data;
            $data_in["infotable_id"] = $id;
            // var_dump($data_in);
            $model = new Model(self::DNS_SCHEMA);
            $model->insertwithdata($data_in);
        }
    }

    /**
     * 
     * @param type $data
     * @param type $id
     */
    static public function insert_message($data, $id) {
        if (is_array($data) && count($data) > 1) {
            $data_in = $data;
            $data_in["infotable_id"] = $id;
            $model = new Model(self::MESSAGE_SCHEMA);
            $model->insertwithdata($data_in);
        }
    }

    /**
     * 
     * @param type $data
     * @param type $id
     */
    static public function insert_audit($data, $id) {
        if (is_array($data) && count($data) > 1) {
            $data_in = $data;
            $data_in["infotable_id"] = $id;
            $model = new Model(self::AUDIT_SCHEMA);
            $model->insertwithdata($data_in);
        }
    }

    static public function insert_timestamp($data, $id) {
        if (is_array($data) && count($data) > 1) {
            $data_in = $data;
            $data_in["infotable_id"] = $id;
            $model = new Model(self::TIMESTAMP_SCHEMA);
            $model->insertwithdata($data_in);
        }
    }

    static public function insert_generic($schema, $data, $id) {
        if (is_array($data) && count($data) > 1) {
            $data_in = $data;
            $data_in["infotable_id"] = $id;
            $model = new Model($schema);
            $model->insertwithdata($data_in);
        }
    }

}
