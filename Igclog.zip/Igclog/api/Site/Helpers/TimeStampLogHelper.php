<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace Site\Helpers;

/**
 * Description of TimeStampLogHelper
 *
 * @author 91939
 */
class TimeStampLogHelper {

    //put your code here
    private $_line = "";
    //
    private $_exploded_arr = [];
    //
    private $_out = [];
    //
    private $_start_flag = 0;
    
     // get value
    private function get_value($index) {
        return isset($this->_exploded_arr[$index]) ? trim($this->_exploded_arr[$index]) : "";
    }

    /**
     * 
     * @return type
     */
    private function get_date_time() {
        $date_str = $this->get_value(0);
        $month_number = substr($date_str, 2, 2);
        $day = substr($date_str, 4, 2);
        $time = $this->get_value(1);
        $year = substr($date_str, 0, 2);
        return [$year . "-" . $month_number . "-" . $day ,$time];
    }

    private function extract_data() {
        list($this->_out["cdate"], $this->_out["ctime"]) = $this->get_date_time();
        $this->_out["deamon_id"] = $this->get_value(2);
        $exploded = array_filter(explode(" ",$this->get_value(3)));
        $this->_out["qry"] = isset($exploded[0]) ? preg_replace("/[^A-Za-z]/", "", $exploded[0]) : "";
        $this->_out["qry"] = str_replace("Query","",$this->_out["qry"]);
        $this->_out["command"] = "Query";
        $this->_out["qry_no"] = trim($this->get_value(5));
        $this->_out["qry_type"]  = "Query";
        $msg_arr = array_slice($this->_exploded_arr, 6);
        $this->_out["qry_details"]  = str_replace("Query", "", implode(" ", $msg_arr));
        
    }

    private function get_paratmers_with_type() {
        switch ($this->_out["qry_type"]) {
            case "queries": $this->get_query_parameters();
                break;
            case "dnssec": $this->get_dnsec_parameters();
                break;
            default: break;
        }
    }

    private function process_this_line() {
        $final_arr = array_merge($GLOBALS["qline"], $this->_exploded_arr);
        $this->_exploded_arr = array_filter($final_arr);
        $this->extract_data();
        //var_dump($this->_exploded_arr);
    }

    private function start_processing() {
        if (!isset($GLOBALS["qstart"])) {
            $fourth_param = isset($this->_exploded_arr[3]) ? 
                    trim(strtolower(preg_replace("/[^A-Za-z]/", "", $this->_exploded_arr[3]))) : "";
            //echo "fparam = " . $fourth_param;
            if ($fourth_param == "queryselect" || $fourth_param=="queryrollback") {
                $GLOBALS["qstart"] = 1;
                $GLOBALS["qline"] = $this->_exploded_arr;
                //echo "entered";
                return;
            }
            if (isset($GLOBALS["qline"])) {
                $this->process_this_line();
            }
        } else {
            // this is second line 
            unset($GLOBALS["qstart"]);
            $this->process_this_line();
            //$this->_out = $this->_exploded_arr;
            //$this->_out["line"] = $GLOBALS["qline"];
        }
    }

    public function get_data($line) {
        $this->_line = $line;
        // explode
        $this->_exploded_arr = explode(" ", $line);
        //
        $first_param = isset($this->_exploded_arr[0]) ? $this->_exploded_arr[0] : "";
        //
        if (is_numeric($first_param)) {
            $GLOBALS["tstart"] = 1;
        }
        $this->_out = [];
        if (isset($GLOBALS["tstart"])) {
            //var_dump($this->_exploded_arr);
            $this->start_processing();
            //var_dump($this->_out);
        }
        // extract common variables
        //  $this->common_data();
        // get the paramters based on dns type
        // $this->get_paratmers_with_type();
        //
        //var_dump($this->_out);
        // return 
        return $this->_out;
    }

    /**
     * 
     * @param type $line
     */
    static public function getData($line) {
        $obj = new self();
        return $obj->get_data($line);
    }

}
